(function ($) {
    "use strict";

    var SERVER_URL = 'http://196.42.67.189:5000';

    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });

    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });

    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });

    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, { offset: '80%' });

    // Calendar
    $('#calender').datetimepicker({
        inline: true,
        format: 'L'
    });

    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav: false
    });


    fetch(SERVER_URL + '/api/sounds')
        .then(response => response.json())
        .then(data => {
            const sounds = data.sounds;
            const allPredators = data.all_predators;

            const container = $(".sounds-container");
            container.empty();

            sounds.forEach((sound, index) => {
                const audioId = `audio${index + 1}`;

                const predatorButtons = allPredators.map(pred => {
                    const isMapped = sound.predators.includes(pred);
                  return `
    <button 
        class="btn btn-${isMapped ? 'success' : 'secondary'} m-1 predator-btn" 
        data-predator="${pred}"
        data-sound-id="${sound.sound_id}"
        style="border-radius: 20px; font-size: 0.85rem; padding: 4px 12px;"
        >
        ${pred}
    </button>
`;

                }).join('');

                const audioHTML = `
                    <div class="col-sm-6">
                        <div class="audio-group" data-sound-id="${sound.sound_id}">
                            <div class="form-check">
                                <input class="form-check-input audio-radio" type="radio" name="audioSelection" id="${audioId}">
                                <label class="form-check-label" for="${audioId}">
                                    <h6>${sound.sound_name}</h6>
                                </label>
                            </div>
                            <audio preload="auto" controls>
                                <source src="${sound.sound_url}">
                            </audio>
                            <div class="predator-toast-container mt-2" style="display:none">
                                ${predatorButtons}
                            </div>
                        </div>
                    </div>
                `;

                container.append(audioHTML);
            });

            // Reinitialize audio player plugin if needed
            if ($.fn.audioPlayer) {
                $('audio').audioPlayer();
            }

            // Radio change handler
            $('.audio-radio').on('change', function () {




            // Toast predator button click handler - assigns sound_id to predator
$(document).on('click', '.predator-btn', function () {
    const button = $(this);
    const pred = button.data('predator');
    const soundId = button.data('sound-id');

    fetch(`${SERVER_URL}/api/update_sounds/${pred}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ sound_id: soundId })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to update predator');
        }
        return response.json();
    })
    .then(data => {
        console.log(`Predator ${pred} assigned to sound ${soundId}`);

        // Update the button UI to show success
        button
            .removeClass('btn-secondary btn-outline-secondary btn-danger')
            .addClass('btn-success')
            .html(`<i class="fas fa-check-circle me-1"></i>${pred}`);
    })
    .catch(error => {
        console.error('Error updating predator:', error);
        alert('Failed to update predator. See console for details.');
    });
});




                // Hide all predator containers
                $('.predator-toast-container').hide();

                // Show for the selected one
                const selectedGroup = $(this).closest('.audio-group');
                selectedGroup.find('.predator-toast-container').show();

                const selectedSoundId = selectedGroup.data('sound-id');

                // Unmark predators from other sounds
                $('.predator-btn').each(function () {
                    const btn = $(this);
                    const isCurrent = btn.data('sound-id') === selectedSoundId;
                    const predName = btn.data('predator');
                    const isMapped = sounds.find(s => s.sound_id === selectedSoundId)?.predators.includes(predName);

                    btn
                        .removeClass('btn-success btn-secondary')
                        .addClass(isMapped ? 'btn-success' : 'btn-secondary')
                        .html(predName + (isMapped ? ' <i class="fas fa-check-circle me-1"></i>  ' : '') );
                });
            });

            // Optionally auto-select the first radio
            const firstRadio = $('.audio-radio').first();
            if (firstRadio.length) {
                firstRadio.prop('checked', true).trigger('change');
            }
        })
        .catch(error => {
            console.error('Error loading sounds:', error);
        });

})(jQuery);
