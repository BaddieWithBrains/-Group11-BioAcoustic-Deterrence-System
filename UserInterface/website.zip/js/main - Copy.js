(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });


    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, {offset: '80%'});


    // Calender
    $('#calender').datetimepicker({
        inline: true,
        format: 'L'
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav : false
    });

var SERVER_URL = 'http:///196.42.65.56:5000';

// Fetch and Update Detections Today 
function updateDetectionsToday() {
    $.get(SERVER_URL + '/get_detections_today', function(data) {
        if ($('#detections-today').length) {
            $('#detections-today').text(data.detections_today);
        }
    }).fail(function(error) {
        console.error('Error fetching detections today:', error);
    });
}

// Call once when page loads
updateDetectionsToday();

// Optionally refresh every 10 seconds
//setInterval(updateDetectionsToday, 10000);


// Fetch and Update Total Detections (with jQuery)
function updateTotalDetections() {
    $.get(SERVER_URL + '/get_total_detections', function(data) {
        if ($('#total-detections').length) {
            $('#total-detections').text(data.total_detections);
        }
    }).fail(function(error) {
        console.error('Error fetching total detections:', error);
    });
}

// Call once when page loads
updateTotalDetections();

// Optionally refresh every 10 seconds
//setInterval(updateTotalDetections, 10000);


// Fetch and Update Total Detections (with jQuery)
function updateLastDetection() {
    $.get(SERVER_URL + '/last_detection', function(data) {
        if ($('#last-detection').length) {
            $('#last-detection').text(data.last_detection);
        }
    }).fail(function(error) {
        console.error('Error fetching last detection:', error);
    });
}

// Call once when page loads
updateLastDetection();

// Optionally refresh every 60 seconds
//setInterval(updateLastDetection, 60000);


fetch(SERVER_URL + '/get_detections')
    .then(response => response.json())
    .then(data => {
        var ctx1 = $("#predator-detections").get(0).getContext("2d");
        var myChart1 = new Chart(ctx1, {
            type: "bar",
            data: {
                labels: data.labels, // Dynamic labels
                datasets: [{
                    label: "Detections",
                    data: data.data, // Dynamic values
                    backgroundColor: "rgba(59, 130, 246, 0.8)",
                    borderColor: "rgba(59, 130, 246, 1)",
                    borderWidth: 1,
                    barThickness: 30,
                    maxBarThickness: 35
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: 2,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: "#111827",
                        titleColor: "#f9fafb",
                        bodyColor: "#d1d5db"
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: "Frequency",
                            color: "#6b7280",
                            font: {
                                size: 12,
                                weight: "bold"
                            }
                        },
                        ticks: {
                            color: "#6b7280"
                        },
                        grid: {
                            color: "#e5e7eb"
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: "Predator Name",
                            color: "#6b7280",
                            font: {
                                size: 12,
                                weight: "bold"
                            }
                        },
                        ticks: {
                            color: "#6b7280"
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error loading detection data:', error));



 
  
        // === Notifications Handling ===
    

function getTimeAgo(timestamp) {
  // Remove timezone information (e.g., +00:00) from the timestamp
  const localTimestamp = timestamp.replace(/([+-]\d{2}):(\d{2})$/, '');

  // Parse the local timestamp
  const date = new Date(localTimestamp);

  // Get the current time
  const now = new Date();

  // Calculate the time difference in seconds
  const diffInSeconds = Math.floor((now - date) / 1000);
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  const diffInHours = Math.floor(diffInMinutes / 60);
  const diffInDays = Math.floor(diffInHours / 24);
  const diffInMonths = Math.floor(diffInDays / 30);
  const diffInYears = Math.floor(diffInDays / 365);

  // Return the appropriate time ago string
  if (diffInSeconds < 60) {
    return `${diffInSeconds} second${diffInSeconds !== 1 ? 's' : ''} ago`;
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
  } else if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
  } else if (diffInDays < 30) {
    return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
  } else if (diffInMonths < 12) {
    return `${diffInMonths} month${diffInMonths !== 1 ? 's' : ''} ago`;
  } else {
    return `${diffInYears} year${diffInYears !== 1 ? 's' : ''} ago`;
  }
}


function loadNotifications() {
    $.get(SERVER_URL + '/get_notifications', function (notifications) {
        const dropdownMenu = $('.dropdown-menu.dropdown-menu-end');
        const notifs = $('#notification-count');
        const notifLink = $('#notification-link');
        dropdownMenu.empty();

              let unreadCount = 0;

        if (notifications.length === 0) {
            dropdownMenu.append('<span class="dropdown-item text-muted">No notifications</span>');
        } else {
            notifications.forEach(notification => {
                const readClass = notification.status === 'R' ? 'text-muted' : 'fw-bold';
                const timeAgo = getTimeAgo(notification.time);
                if (notification.status !== 'R') 
                     {
                        unreadCount++;
                     }
                          

                const item = $(`
                    <a href="#" class="dropdown-item ${readClass}" data-id="${notification.id}">
                        <h6 class="mb-0">${notification.message}</h6>
                        <small class="text-muted">${timeAgo}</small>
                    </a>
                `);

                item.on('click', function (e) {
                    e.preventDefault();
                    const id = $(this).data('id');

                    $.post(SERVER_URL + '/notifications/read/' + id, function () {
                        loadNotifications();
                    }).fail(function () {
                        alert('Failed to update notification.');
                    });
                });

                dropdownMenu.append(item);


            });
            notifs.html(unreadCount);
           
           if (unreadCount > 0) {
    notifLink.css({
        'color': '#007bff'
        
   
    });
    notifs.css({
        'color': '#007bff',
        'font-weight': 'bold'
    });
} else {
    notifLink.css({
        'background-color': '',
        'border-radius': '',
        'box-shadow': '',
        'transition': ''
    });
    notifs.css({
        'color': '',
        'font-weight': ''
    });
}


}
          
    }).fail(function () {
        console.error('Failed to fetch notifications.');
    });
}

// Call on page load
loadNotifications();







    // Optionally refresh every 60 seconds
    // setInterval(loadNotifications, 60000);



    
})(jQuery);

