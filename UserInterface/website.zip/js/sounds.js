(function ($) {
    "use strict";

    const SERVER_URL = 'http://192.168.228.191:5000';  // fixed URL here
    let selectedSoundId = null;

    const spinner = function () {
        setTimeout(() => $('#spinner').removeClass('show'), 1);
    };
    spinner();

    // Back to top
    $(window).scroll(function () {
        $(this).scrollTop() > 300
            ? $('.back-to-top').fadeIn('slow')
            : $('.back-to-top').fadeOut('slow');
    });

    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });

    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });

    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, { offset: '80%' });

    $('#calender').datetimepicker({ inline: true, format: 'L' });

    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav: false
    });

    // Load and render all sounds
    function loadSounds() {
        fetch(SERVER_URL + '/sounds', {
            credentials: 'include'  // **include credentials here**
        })
        .then(response => response.json())
        .then(data => {
            const { sounds, all_predators } = data;
            const container = $(".sounds-container");
            container.empty();

            sounds.forEach((sound, index) => {
                const audioId = `audio${index + 1}`;
                const predatorButtons = all_predators.map(pred => {
                    const isMapped = sound.predators.includes(pred);
                    return `
                        <button 
                            class="btn btn-${isMapped ? 'success' : 'secondary'} m-1 predator-btn" 
                            data-predator="${pred}"
                            data-sound-id="${sound.sound_id}"
                            style="border-radius: 20px; font-size: 0.85rem; padding: 4px 12px;">
                            ${isMapped ? `<i class="fas fa-check-circle me-1"></i>${pred}` : pred}
                        </button>
                    `;
                }).join('');

                const audioHTML = `
                    <div class="col-sm-6">
                        <div class="audio-group" data-sound-id="${sound.sound_id}">
                            <div class="form-check">
                                <input class="form-check-input audio-radio" type="radio" name="audioSelection" id="${audioId}">
                                <label class="form-check-label" for="${audioId}">
                                    <h6>${sound.sound_name}</h6>
                                </label>
                            </div>
                            <audio preload="auto" controls>
                                <source src="${sound.sound_url}">
                            </audio>
                            <div class="predator-toast-container mt-2" style="display:none">
                                ${predatorButtons}
                            </div>
                        </div>
                    </div>
                `;
                container.append(audioHTML);
            });

            if ($.fn.audioPlayer) {
                $('audio').audioPlayer();
            }

            attachEventHandlers(data.sounds);

            let restored = false;
            $('.audio-radio').each(function () {
                const group = $(this).closest('.audio-group');
                if (group.data('sound-id') === selectedSoundId) {
                    $(this).prop('checked', true).trigger('change');
                    restored = true;
                }
            });

            if (!restored) {
                const firstRadio = $('.audio-radio').first();
                if (firstRadio.length) {
                    firstRadio.prop('checked', true).trigger('change');
                }
            }
        })
        .catch(error => console.error('Error loading sounds:', error));
    }

    // Handle audio selection
    function handleRadioChange(sounds) {
        $('.audio-radio').on('change', function () {
            $('.predator-toast-container').hide();

            const selectedGroup = $(this).closest('.audio-group');
            selectedGroup.find('.predator-toast-container').show();
            selectedSoundId = selectedGroup.data('sound-id');

            $('.predator-btn').each(function () {
                const btn = $(this);
                const predName = btn.data('predator');
                const soundId = selectedGroup.data('sound-id');
                const isMapped = sounds.find(s => s.sound_id === soundId)?.predators.includes(predName);

                btn.removeClass('btn-success btn-secondary')
                    .addClass(isMapped ? 'btn-success' : 'btn-secondary')
                    .html(isMapped ? `<i class="fas fa-check-circle me-1"></i>${predName}` : predName);
            });
        });
    }

    // Handle predator button click
    function handlePredatorClick() {
        $(document).on('click', '.predator-btn', function () {
            const button = $(this);
            const pred = String(button.data('predator')).trim().toLowerCase();
            const soundId = button.data('sound-id');

            fetch(`${SERVER_URL}/update_sounds/${pred}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',  // **include credentials here too**
                body: JSON.stringify({ sound_id: soundId })
            })
            .then(response => {
                if (!response.ok) throw new Error('Failed to update predator');
                return response.json();
            })
            .then(() => {
                selectedSoundId = soundId;
                loadSounds();
            })
            .catch(error => {
                console.error('Error updating predator:', error);
                alert('Failed to update predator. See console for details.');
            });
        });
    }

    // Attach all dynamic event handlers
    function attachEventHandlers(sounds) {
        handleRadioChange(sounds);
        // handlePredatorClick already bound globally
    }

    // Initial load
    handlePredatorClick(); // Global bind once
    loadSounds();


    // === Notifications Handling ===
    function getTimeAgo(timestamp) {
        const localTimestamp = timestamp.replace(/([+-]\d{2}):(\d{2})$/, '');
        const date = new Date(localTimestamp);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        const diffInMinutes = Math.floor(diffInSeconds / 60);
        const diffInHours = Math.floor(diffInMinutes / 60);
        const diffInDays = Math.floor(diffInHours / 24);
        const diffInMonths = Math.floor(diffInDays / 30);
        const diffInYears = Math.floor(diffInDays / 365);

        if (diffInSeconds < 60) return `${diffInSeconds} second${diffInSeconds !== 1 ? 's' : ''} ago`;
        if (diffInMinutes < 60) return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
        if (diffInHours < 24) return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
        if (diffInDays < 30) return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
        if (diffInMonths < 12) return `${diffInMonths} month${diffInMonths !== 1 ? 's' : ''} ago`;
        return `${diffInYears} year${diffInYears !== 1 ? 's' : ''} ago`;
    }

    function loadNotifications() {
        $.ajax({
            url: SERVER_URL + '/get_notifications',
            method: 'GET',
            xhrFields: { withCredentials: true },  // include credentials here too
            success: function (notifications) {
                const dropdownMenu = $('.dropdown-menu.dropdown-menu-end');
                const notifs = $('#notification-count');
                const notifLink = $('#notification-link');
                dropdownMenu.empty();

                let unreadCount = 0;

                if (notifications.length === 0) {
                    dropdownMenu.append('<span class="dropdown-item text-muted">No notifications</span>');
                } else {
                    notifications.forEach(notification => {
                        const readClass = notification.status === 'R' ? 'text-muted' : 'fw-bold';
                        const timeAgo = getTimeAgo(notification.time);
                        if (notification.status !== 'R') unreadCount++;

                        const item = $(`
                            <a href="#" class="dropdown-item ${readClass}" data-id="${notification.id}">
                                <h6 class="mb-0">${notification.message}</h6>
                                <small class="text-muted">${timeAgo}</small>
                            </a>
                        `);

                        item.click(function (e) {
                            e.preventDefault();
                            const notifId = $(this).data('id');

                            if (notification.status === 'R') return; // Already read

                            $.ajax({
                                url: SERVER_URL + `/mark_read/${notifId}`,
                                method: 'PUT',
                                xhrFields: { withCredentials: true },
                                success: function () {
                                    loadNotifications();  // refresh after marking read
                                },
                                error: function () {
                                    alert('Failed to mark notification as read.');
                                }
                            });
                        });

                        dropdownMenu.append(item);
                    });
                }

                notifs.text(unreadCount);
                notifLink.text(unreadCount > 0 ? `Notifications (${unreadCount})` : 'Notifications');
            },
            error: function () {
                console.error('Failed to load notifications');
            }
        });
    }

    // Refresh notifications every 30 seconds
    setInterval(loadNotifications, 30000);
    loadNotifications();

})(jQuery);
